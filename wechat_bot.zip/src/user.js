module.exports = function user(user) {
  console.log(`User ${user} logged in`);
}